from dolfin import *
from dolfin_adjoint import *
set_log_level(LogLevel.ERROR)

# We load the facet marker values used in the mesh, as well as some
# geometrical quantities mesh-generator file.

from create_mesh import inflow, outflow, walls, obstacle

# The initial (unperturbed) mesh and corresponding facet function from their respective
# xdmf-files.
mesh = Mesh()
with XDMFFile("mesh.xdmf") as infile:
    infile.read(mesh)
    mvc = MeshValueCollection("size_t", mesh, 1)
with XDMFFile("mf.xdmf") as infile:
    infile.read(mvc, "name_to_read")
    mf = cpp.mesh.MeshFunctionSizet(mesh, mvc)

b_mesh = BoundaryMesh(mesh, "exterior")
S_b = VectorFunctionSpace(b_mesh, "CG", 1)
h = Function(S_b, name="Design")
h_V = transfer_from_boundary(h, mesh)
h_V.rename("Volume extension of h", "")

# Remove gradient contributions from the fixed boundaries,
# Using a H1-Riesz representation in the volume to deform the mesh
# This can be exchanged into any other deformation scheme
dObs = Measure("ds", subdomain_data=mf, subdomain_id=obstacle)
S= h_V.function_space()
u, v = TrialFunction(S), TestFunction(S)
a = inner(grad(u),grad(v))*dx + inner(u,v)*dx
l = inner(Constant((0,0)), v)*dx
bcs_def = []
for marker in [inflow, outflow, walls]:
    bcs_def.append(DirichletBC(S, Constant((0,0)), mf, marker))
bcs_def.append(DirichletBC(S, h_V, mf, obstacle))
mesh_movement = Function(S)
solve(a==l, mesh_movement, bcs=bcs_def)

ALE.move(mesh, mesh_movement)

# The next step is to set up :eq:`state`. We start by defining the
# stable Taylor-Hood finite element space.

V2 = VectorElement("CG", mesh.ufl_cell(), 3)
S1 = FiniteElement("CG", mesh.ufl_cell(), 2)
VQ = FunctionSpace(mesh, V2*S1)

# Then, we define the test and trial functions, as well as the variational form

(u, p) = TrialFunctions(VQ)
(v, q) = TestFunctions(VQ)
a = inner(grad(u), grad(v))*dx - div(u)*q*dx - div(v)*p*dx
l = inner(Constant((0,0)), v)*dx

# The Dirichlet boundary conditions on :math:`\Gamma` is defined as follows

(x,y) = SpatialCoordinate(mesh)
g = Expression(("sin(pi*x[1])","0"),degree=2)
bc_inlet = DirichletBC(VQ.sub(0), g, mf, inflow)
bc_obstacle = DirichletBC(VQ.sub(0), Constant((0,0)) , mf, obstacle)
bc_walls = DirichletBC(VQ.sub(0), Constant((0,0)), mf, walls)
bcs = [bc_inlet, bc_obstacle, bc_walls]

# We solve the mixed equations and split the solution into the velocity-field
# :math:`u` and pressure-field :math:`p`.

w = Function(VQ, name="Mixed State Solution")
solve(a==l, w, bcs=bcs)
u, p = w.split()

# Plotting the initial velocity and pressure

# Minimize drag
n = FacetNormal(mesh)
J = assemble(p*n[0]*dObs)
Jhat = ReducedFunctional(J, Control(h))

#Compute gradient
dJdm = Jhat.derivative()

# Transfer to volume function so it can be visualized in Paraview
dJdm_vol_func = transfer_from_boundary(dJdm, mesh)
File("gradient.pvd").write(dJdm_vol_func)

# Taylor test checking that all the residuals are as expected
perturbation = interpolate(Expression(("-x[0]", "x[1]"),
                                      degree=2), S_b)
results = taylor_to_dict(Jhat, Function(S_b), perturbation)
print(results)
